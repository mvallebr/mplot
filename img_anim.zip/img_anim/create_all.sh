#!/bin/sh

echo Starting convertion...
for file in *.txt
do
	echo
	echo
	echo
	echo Arquivo: $file
	echo
	echo Converting  $file image
	len=$(expr length $file - 4)
	file=$(expr substr $file 1 $len)
	
	rm -f $file.2.txt
	./limit_columns $file.txt $file.2.txt 6 float
	cp -f $file.2.txt dens.doc
	rm -f $file.2.txt
	
	scilab -nw -f plotom2.sci > temp2.fig
	head -n 5 temp.fig > $file.fig
	more +14 temp2.fig >> $file.fig 
	
	convert -verbose -colorspace GRAY $file.fig $file.jpg
	convert -verbose -rotate 180 -colorspace GRAY $file.jpg $file-180.bmp
	convert -verbose -rotate 270 -colorspace GRAY $file.jpg $file-270.bmp
	rm -f $file.fig
	stty sane
	#ini=$(expr length $dir + 2)
	#onlyf=$(expr substr $file $ini $len)
done  #file

