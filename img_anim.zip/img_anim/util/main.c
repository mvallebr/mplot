#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TAM_BUFFER 10000
#define MAX_COLUMNS 10

void construct_format_string(char *substr, int num_args, char *str);

int main(int argc, char *argv[]) {
  int i, num_columns, columns_read;
  FILE *fin, *fout;
  char buffer[TAM_BUFFER];
  char substr[10], format_str[1000];
  int  argi[MAX_COLUMNS];
  char  argch[MAX_COLUMNS];
  float  argf[MAX_COLUMNS];
  double  argd[MAX_COLUMNS];
  int actual_line=0;
  
  if (argc<4) {
    fprintf(stderr, "Usage: %s filename_input filename_output NumColumns [argtype]\n", argv[0]);
    fprintf(stderr, "argtype can be: double, float, int or char - defaults to int\n");
    return 1;
  }
  num_columns = atoi(argv[3]);
  printf("Using %d columns...\n", num_columns);
  if (num_columns<1) {
    fprintf(stderr, "Invalid number of columns: %d", num_columns);
    return 2;
  }
  if (num_columns>MAX_COLUMNS) {
    fprintf(stderr, "Invalid number of columns: %d", num_columns);
    return 2;
  }
  
  fin = fopen(argv[1], "r");
  if (!fin) {
    fprintf(stderr, "Can't open input file: %s\n", argv[1]);
    return 2;
  }
  printf("Using %s as input\n", argv[1]);
  fout = fopen(argv[2], "r");
  if (fout) {
    fprintf(stderr, "File alredy exists: %s\n", argv[2]);
    fclose(fout);
    return 3;
  }
  fout = fopen(argv[2], "w");
  if (!fout) {
    fprintf(stderr, "Can't open output file: %s\n", argv[2]);
    return 4;
  }
  printf("Using %s as output\n", argv[2]);
  if (argc<5) { //User didn't passed argtype
    strcpy(substr, "%i");
  } else {
    if (!strcmp(argv[4], "int"))
      strcpy(substr, "%i");
    else if (!strcmp(argv[4], "float"))
      strcpy(substr, "%f");
    else if (!strcmp(argv[4], "double"))
      strcpy(substr, "%F");
    else if (!strcmp(argv[4], "char"))
      strcpy(substr, "%c");
    else
      strcpy(substr, "%i");
  }
  printf("Using string '%s' for type\n", substr);
  construct_format_string(substr, num_columns, format_str);
  printf("Using string '%s' for format\n", format_str);
  while (!feof(fin)) {
    actual_line++;
    fgets(buffer, TAM_BUFFER, fin);
    switch (num_columns) {
    case 1:
      columns_read = sscanf(buffer, format_str, &argf[0]);
      break;
    case 2:
      columns_read = sscanf(buffer, format_str, &argf[0], &argf[1]);
      break;
    case 3:
      columns_read = sscanf(buffer, format_str, &argf[0], 
			    &argf[1], &argf[2]);
      break;
    case 4:
      columns_read = sscanf(buffer, format_str, &argf[0]
			    , &argf[1], &argf[2], &argf[3]);
      break;
    case 5:
      columns_read = sscanf(buffer, format_str, &argf[0]
			    , &argf[1], &argf[2], &argf[3], &argf[4]);
      break;
    case 6:
      columns_read = sscanf(buffer, format_str, &argf[0]
			    , &argf[1], &argf[2], &argf[3], &argf[4]
			    , &argf[5]);
      break;
    case 7:
      columns_read = sscanf(buffer, format_str, &argf[0]
			    , &argf[1], &argf[2], &argf[3], &argf[4]
			    , &argf[5], &argf[6]);
      break;
    case 8:
      columns_read = sscanf(buffer, format_str, &argf[0]
			    , &argf[1], &argf[2], &argf[3], &argf[4]
			    , &argf[5], &argf[6], &argf[7]);
      break;
    case 9:
      columns_read = sscanf(buffer, format_str, &argf[0]
			    , &argf[1], &argf[2], &argf[3], &argf[4]
			    , &argf[5], &argf[6], &argf[7], &argf[8]);
      break;
    case 10:
      columns_read = sscanf(buffer, format_str, &argf[0]
			    , &argf[1], &argf[2], &argf[3], &argf[4]
			    , &argf[5], &argf[6], &argf[7], &argf[8]
			    , &argf[9]);
      break;
    default: 
      break;
    }		
    //printf("columns_read = %d\n", columns_read);
    if (columns_read!=num_columns) {
      printf("Line %d doesn't match: \n%s", actual_line, buffer);
    } else {
      switch (num_columns) {
      case 1:
	fprintf(fout, format_str, argf[0]);
	break;
      case 2:
	fprintf(fout, format_str, argf[0], argf[1]);
	break;
      case 3:
	fprintf(fout, format_str, argf[0], 
			      argf[1], argf[2]);
	break;
      case 4:
	fprintf(fout, format_str, argf[0]
			      , argf[1], argf[2], argf[3]);
	break;
      case 5:
	fprintf(fout, format_str, argf[0]
			      , argf[1], argf[2], argf[3], argf[4]);
	break;
      case 6:
	fprintf(fout, format_str, argf[0]
			      , argf[1], argf[2], argf[3], argf[4]
			      , argf[5]);
	break;
      case 7:
	fprintf(fout, format_str, argf[0]
			      , argf[1], argf[2], argf[3], argf[4]
			      , argf[5], argf[6]);
	break;
      case 8:
	fprintf(fout, format_str, argf[0]
			      , argf[1], argf[2], argf[3], argf[4]
			      , argf[5], argf[6], argf[7]);
	break;
      case 9:
	fprintf(fout, format_str, argf[0]
			      , argf[1], argf[2], argf[3], argf[4]
			      , argf[5], argf[6], argf[7], argf[8]);
	break;
      case 10:
	columns_read = sscanf(buffer, format_str, argf[0]
			      , argf[1], argf[2], argf[3], argf[4]
			      , argf[5], argf[6], argf[7], argf[8]
			      , argf[9]);
	break;
      default: 
	break;
      }		
    }
  }
	
  fclose(fin);
  fclose(fout);
  return 0;
}

void construct_format_string(char *substr, int num_args, char *str) {
  int i;
  if (num_args<1){
    strcpy(str, "");
    return;
  }
  strcpy(str, substr);
  for (i=1; i<num_args; i++) {
    strcat(str, " ");
    strcat(str, substr);
  }
  strcat(str, "\n");
}



